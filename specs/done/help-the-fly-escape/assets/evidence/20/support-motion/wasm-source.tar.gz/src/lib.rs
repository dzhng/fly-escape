use sim::surface::{ContactHull,ContactScene,ContactSurface};
use parry3d_f64::shape::Ball;
use wasm_bindgen::prelude::*;
#[wasm_bindgen]
pub fn report() -> String {
    let (vertices,triangles)=Ball::new(0.04).to_trimesh(32,16);
    let surface=ContactSurface{id:7,vertices:vertices.into_iter().map(|v|[v.x,v.y+0.04,v.z]).collect(),triangles};
    let scene=ContactScene::new(std::slice::from_ref(&surface)).unwrap();
    let mut points=vec![];
    for x in [-0.001,0.001] {for y in [0.,0.0018] {for z in [-0.0015,0.0015] {points.push([x,y,z]);}}}
    let hull=ContactHull::new(&points).unwrap();let mut cases=vec![];
    for x in [-0.03,-0.015,0.,0.015,0.03] {
        let hit=scene.cast(&hull,[x,0.2,0.],0.,[0.,1.,0.],[0.,-0.4,0.]).unwrap().unwrap();
        let departure=scene.cast(&hull,[x,0.2-0.4*hit.fraction,0.],0.,[0.,1.,0.],[0.,0.2,0.]).unwrap();
        assert!(departure.is_none());
        let support=scene.below([x,0.2,0.],0.4).unwrap().unwrap();
        for _ in 0..100 {assert_eq!(scene.cast(&hull,[x,0.2,0.],0.,[0.,1.,0.],[0.,-0.4,0.]).unwrap(),Some(hit));}
        cases.push(serde_json::json!({"hit":hit,"departure":departure,"support":support,"rotation":sim::surface::support_rotation(std::f64::consts::FRAC_PI_2,support.normal).unwrap()}));
    }
    let points: Vec<[f64; 3]> = serde_json::from_str(include_str!("../native-hull.json")).unwrap();
    let native = ContactHull::new(&points).unwrap();
    let floor = ContactSurface { id: 0, vertices: vec![[-1., 0., -1.], [1., 0., -1.], [1., 0., 1.], [-1., 0., 1.]], triangles: vec![[0, 2, 1], [0, 3, 2]] };
    let floor_scene = ContactScene::new(&[floor]).unwrap();
    let mut native_cases = vec![];
    for x in [-0.03, 0., 0.03] {
        let landing = floor_scene.cast(&native, [x, 0.2, 0.], 0., [0., 1., 0.], [0., -0.3, 0.]).unwrap().unwrap();
        let root = [x, 0.2 - 0.3 * landing.fraction, 0.];
        for delta in [[0.001, 0., 0.], [-0.001, 0., 0.], [0., 0., 0.001], [0., 0.001, 0.]] {
            assert!(floor_scene.cast(&native, root, 0., [0., 1., 0.], delta).unwrap().is_none());
        }
        let into_floor = floor_scene.cast(&native, root, 0., [0., 1., 0.], [0., -0.001, 0.]).unwrap().unwrap();
        native_cases.push(serde_json::json!({"landing": landing, "root": root, "intoFloor": into_floor}));
    }
    serde_json::to_string(&serde_json::json!({"surface":surface,"cases":cases,"nativeCases":native_cases})).unwrap()
}
