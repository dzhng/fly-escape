use sim::surface::{ContactHull,ContactScene,ContactSurface};
use parry3d_f64::shape::Ball;
use wasm_bindgen::prelude::*;
#[wasm_bindgen]
pub fn report() -> String {
    let (vertices,triangles)=Ball::new(0.04).to_trimesh(32,16);
    let scene=ContactScene::new(&[ContactSurface{id:7,vertices:vertices.into_iter().map(|v|[v.x,v.y+0.04,v.z]).collect(),triangles}]).unwrap();
    let mut points=vec![];
    for x in [-0.001,0.001] {for y in [0.,0.0018] {for z in [-0.0015,0.0015] {points.push([x,y,z]);}}}
    let hull=ContactHull::new(&points).unwrap();let mut cases=vec![];
    for x in [-0.03,-0.015,0.,0.015,0.03] {
        let hit=scene.cast(&hull,[x,0.2,0.],0.,[0.,1.,0.],[0.,-0.4,0.]).unwrap().unwrap();
        let departure=scene.cast(&hull,[x,0.2-0.4*hit.fraction,0.],0.,[0.,1.,0.],[0.,0.2,0.]).unwrap();
        assert!(departure.is_none());
        let support=scene.below([x,0.2,0.],0.4).unwrap().unwrap();
        for _ in 0..100 {assert_eq!(scene.cast(&hull,[x,0.2,0.],0.,[0.,1.,0.],[0.,-0.4,0.]).unwrap(),Some(hit));}
        cases.push(serde_json::json!({"hit":hit,"departure":departure,"support":support}));
    }
    serde_json::to_string(&cases).unwrap()
}
